# video-slider
Video slider using HTML,CSS, JavaScript.
Created the video slider with an image navigation in the center and video will be played in the section cover.



Credit :- Online Tutorials
